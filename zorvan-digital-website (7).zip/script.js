// Zorvan Digital — edit these settings before publishing.
const CONTACT = {
  email: "hello@zorvandigital.com", // Replace with your real business email.
  whatsapp: "",                     // Country code + number, digits only. Example: 923001234567
  linkedin: ""                      // Paste your LinkedIn profile or company page URL.
};

document.getElementById("year").textContent = new Date().getFullYear();

const emailButton = document.getElementById("emailButton");
if (CONTACT.email && !CONTACT.email.includes("your-email")) {
  emailButton.href = `mailto:${CONTACT.email}`;
}

const whatsappButton = document.getElementById("whatsappButton");
if (CONTACT.whatsapp.trim()) {
  whatsappButton.href = `https://wa.me/${CONTACT.whatsapp.replace(/\D/g, "")}`;
  whatsappButton.target = "_blank";
  whatsappButton.rel = "noopener noreferrer";
} else {
  whatsappButton.href = `mailto:${CONTACT.email}?subject=${encodeURIComponent("Project enquiry — Zorvan Digital")}`;
  whatsappButton.title = "Add your WhatsApp number in script.js to activate this link.";
}

const linkedinButton = document.getElementById("linkedinButton");
if (CONTACT.linkedin.trim()) {
  linkedinButton.href = CONTACT.linkedin;
  linkedinButton.target = "_blank";
  linkedinButton.rel = "noopener noreferrer";
} else {
  linkedinButton.href = `mailto:${CONTACT.email}?subject=${encodeURIComponent("Connect with Zorvan Digital")}`;
  linkedinButton.title = "Add your LinkedIn URL in script.js to activate this link.";
}

const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "×" : "☰";
});
navLinks.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  });
});
