# Zorvan Digital Website

A responsive, one-page agency website built with plain HTML, CSS, and JavaScript.

## Files
- `index.html` — page content
- `style.css` — design and responsive layout
- `script.js` — navigation and contact links

## Before publishing
1. Open `script.js`.
2. Replace `hello@zorvandigital.com` with your real email.
3. Add your WhatsApp number to `whatsapp` in international format without `+`, spaces, or dashes (Pakistan example: `923001234567`).
4. Add your LinkedIn profile or company-page URL to `linkedin`.
5. Save all files and upload them to your GitHub repository.

## Publish with GitHub Pages
1. Create a public GitHub repository named `zorvan-digital` (or another available name).
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then click **Save**.
6. Wait for GitHub Pages to publish and open the URL shown in Settings → Pages.

The website uses a single-page layout with navigation links that scroll to each section.
